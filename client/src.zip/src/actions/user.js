const setUser = () => {

}

const startAddUser = () => {
    return (dispatch) => {
        
    }
}