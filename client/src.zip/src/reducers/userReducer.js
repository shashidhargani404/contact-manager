const userInitialState = {}

const userReducer = (state=userInitialState, action) {
    switch(action.type) {
        default: {
            return {...state}
        }
    }
}

export default userReducer